Get["CustomTicks`CustomTicks`"];
