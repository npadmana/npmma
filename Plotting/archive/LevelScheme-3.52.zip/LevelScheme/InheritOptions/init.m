(* ::Package:: *)

Get["InheritOptions`InheritOptions`"];
