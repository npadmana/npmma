(* ::Package:: *)

Get["ClipToRectangle`ClipToRectangle`"];
