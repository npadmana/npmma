(* ::Package:: *)

Get["NamedColors`NamedColors`"];
